# Gonzo Wildcards

A set of useful wildcards for mixing up prompts.

## Usage

Clone or copy these files to 

`[your path to]/stable-diffusion-webui/extensions/sd-dynamic-prompts/wildcards/gonzo/`

Hit refesh wildcards on the wildcards table in Stable Diffusion Web UI

Make sure Dynamic Prompts is activated and write a prompt like so: 

`cartoon drawing of  __gonzo/people/hiphop__  , trending on artstation, HD, ((high quality)), vibrant color scheme, character design`

and you will get something like: 

`cartoon drawing of Ray Charles , trending on artstation, HD, ((high quality)), vibrant color scheme, character design`

